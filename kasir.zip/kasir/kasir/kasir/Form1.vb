﻿
Imports Newtonsoft.Json
Public Class Form1
    Private Sub cmbitem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbitem.SelectedIndexChanged
        If cmbitem.Text = "Sate Ayam" Then
            txtharga.Text = 35000
        ElseIf cmbitem.Text = "Nasi Goreng" Then
            txtharga.Text = 27000
        ElseIf cmbitem.Text = "Ayam Goreng" Then
            txtharga.Text = 20000
        ElseIf cmbitem.Text = "Ayam Geprek" Then
            txtharga.Text = 25000
        ElseIf cmbitem.Text = "Bubur Medan" Then
            txtharga.Text = 40000
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtsubtotal.Text = txtharga.Text * txtjumlah.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txttotal.Text = txtsubtotal.Text - (txtsubtotal.Text * txtdiskon.Text) / 100
        Label2.Text = txttotal.Text
    End Sub

    Private Sub txtbayar_TextChanged(sender As Object, e As EventArgs) Handles txtbayar.TextChanged

    End Sub

    Private Sub txtbayar_Leave(sender As Object, e As EventArgs) Handles txtbayar.Leave
        txtkembali.Text = txtbayar.Text - txttotal.Text
    End Sub

    Private Sub cmbvoucher_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbvoucher.SelectedIndexChanged
        If cmbvoucher.Text = " Akhir Pekan" Then
            txtdiskon.Text = 10
        ElseIf cmbvoucher.Text = "Akhir Bulan" Then
            txtdiskon.Text = 20
        ElseIf cmbvoucher.Text = "Akhir Tahun" Then
            txtdiskon.Text = 30
        ElseIf cmbvoucher.Text = "Tidak Ada" Then
            txtdiskon.Text = 0
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cmbitem.Text = ""
        txtharga.Text = ""
        txtjumlah.Text = ""
        txtsubtotal.Text = ""
        txtdiskon.Text = ""
        txttotal.Text = ""
        txtbayar.Text = ""
        txtkembali.Text = ""
        cmbvoucher.Text = ""
        Label2.Text = 0

        cmbitem.Focus()


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Public Class OrderData
        Public Property Menu As String
        Public Property Harga As Decimal
        Public Property Jumlah As Integer
        Public Property SubTotal As Decimal
        Public Property Diskon As Decimal
        Public Property Total As Decimal
        Public Property UangBayar As Decimal
        Public Property UangKembali As Decimal
        Public Property KodeVoucher As String
    End Class

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        txttotal.Text = txtsubtotal.Text - txtsubtotal.Text * txtdiskon.Text / 100
        Label2.Text = txttotal.Text

        ' Simpan data ke JSON
        Dim order As New OrderData With {
        .Menu = cmbitem.Text,
        .Harga = Decimal.Parse(txtharga.Text),
        .Jumlah = Integer.Parse(txtjumlah.Text),
        .SubTotal = Decimal.Parse(txtsubtotal.Text),
        .Diskon = Decimal.Parse(txtdiskon.Text),
        .Total = Decimal.Parse(txttotal.Text),
        .UangBayar = Decimal.Parse(txtbayar.Text),
        .UangKembali = Decimal.Parse(txtkembali.Text),
        .KodeVoucher = cmbvoucher.Text
    }

        ' Load data lama dari file
        Dim dataList = LoadData()
        dataList.Add(order) ' Tambahkan data baru
        SaveData(dataList) ' Simpan ke file JSON

        MessageBox.Show("Data berhasil disimpan!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function LoadData() As List(Of OrderData)
        Dim filePath As String = "data.json"
        If IO.File.Exists(filePath) Then
            Dim jsonData As String = IO.File.ReadAllText(filePath)
            Return JsonConvert.DeserializeObject(Of List(Of OrderData))(jsonData)
        End If
        Return New List(Of OrderData)()
    End Function

    Private Sub SaveData(data As List(Of OrderData))
        Dim filePath As String = "data.json"
        Dim jsonData As String = JsonConvert.SerializeObject(data, Formatting.Indented)
        IO.File.WriteAllText(filePath, jsonData)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim form2 As New Form2()
        form2.Show()
    End Sub
End Class
