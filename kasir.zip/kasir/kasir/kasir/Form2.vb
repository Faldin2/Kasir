﻿Imports Newtonsoft.Json
Imports System.IO

Public Class Form2
    Public Class OrderData
        Public Property Menu As String
        Public Property Harga As Decimal
        Public Property Jumlah As Integer
        Public Property SubTotal As Decimal
        Public Property Diskon As Decimal
        Public Property Total As Decimal
        Public Property UangBayar As Decimal
        Public Property UangKembali As Decimal
        Public Property KodeVoucher As String
    End Class

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dataList As List(Of OrderData) = LoadData()
        dgvData.DataSource = dataList
    End Sub

    Private Function LoadData() As List(Of OrderData)
        Dim filePath As String = "data.json"
        If File.Exists(filePath) Then
            Dim jsonData As String = File.ReadAllText(filePath)
            Return JsonConvert.DeserializeObject(Of List(Of OrderData))(jsonData)
        End If
        Return New List(Of OrderData)()
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim searchTerm As String = txtCari.Text.Trim()
        Dim found As Boolean = False

        For Each row As DataGridViewRow In dgvData.Rows
            If row.Cells(0).Value IsNot Nothing AndAlso row.Cells(0).Value.ToString().Contains(searchTerm) Then
                row.Selected = True
                dgvData.CurrentCell = row.Cells(0)
                found = True
                Exit For
            End If
        Next

        If Not found Then
            MessageBox.Show("Data tidak ditemukan!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If dgvData.SelectedRows.Count > 0 Then
            Dim confirm As DialogResult = MessageBox.Show("Apakah Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If confirm = DialogResult.Yes Then
                dgvData.Rows.RemoveAt(dgvData.SelectedRows(0).Index)
            End If
        Else
            MessageBox.Show("Pilih baris yang ingin dihapus!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class