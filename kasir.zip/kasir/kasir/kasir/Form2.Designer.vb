﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        dgvData = New DataGridView()
        txtCari = New TextBox()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Panel1.SuspendLayout()
        CType(dgvData, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.Highlight
        Panel1.Controls.Add(Label1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(903, 150)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(96, 50)
        Label1.Name = "Label1"
        Label1.Size = New Size(687, 45)
        Label1.TabIndex = 0
        Label1.Text = "DAFTAR MAKANAN YANG TELAH DI PESAN"
        ' 
        ' dgvData
        ' 
        dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvData.Location = New Point(12, 277)
        dgvData.Name = "dgvData"
        dgvData.RowHeadersWidth = 62
        dgvData.Size = New Size(879, 265)
        dgvData.TabIndex = 1
        ' 
        ' txtCari
        ' 
        txtCari.Font = New Font("Segoe UI", 12F)
        txtCari.Location = New Point(50, 207)
        txtCari.Name = "txtCari"
        txtCari.Size = New Size(310, 39)
        txtCari.TabIndex = 2
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(392, 207)
        Button1.Name = "Button1"
        Button1.Size = New Size(125, 39)
        Button1.TabIndex = 3
        Button1.Text = "Cari"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(550, 209)
        Button2.Name = "Button2"
        Button2.Size = New Size(129, 39)
        Button2.TabIndex = 4
        Button2.Text = "Hapus"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(709, 207)
        Button3.Name = "Button3"
        Button3.Size = New Size(124, 39)
        Button3.TabIndex = 5
        Button3.Text = "Keluar"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(903, 699)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(txtCari)
        Controls.Add(dgvData)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Name = "Form2"
        Text = "Form2"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(dgvData, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents dgvData As DataGridView
    Friend WithEvents txtCari As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
