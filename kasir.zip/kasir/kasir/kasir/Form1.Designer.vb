﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label13 = New Label()
        Label3 = New Label()
        Panel2 = New Panel()
        Label2 = New Label()
        Label1 = New Label()
        cmbitem = New ComboBox()
        txtharga = New TextBox()
        txtjumlah = New TextBox()
        txtsubtotal = New TextBox()
        Button1 = New Button()
        txtdiskon = New TextBox()
        txttotal = New TextBox()
        txtbayar = New TextBox()
        txtkembali = New TextBox()
        Button2 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        cmbvoucher = New ComboBox()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Button5 = New Button()
        Button6 = New Button()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.Highlight
        Panel1.Controls.Add(Label13)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Panel2)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1056, 150)
        Panel1.TabIndex = 0
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.ForeColor = SystemColors.ControlLightLight
        Label13.Location = New Point(53, 89)
        Label13.Name = "Label13"
        Label13.Size = New Size(154, 28)
        Label13.TabIndex = 2
        Label13.Text = "Rumah Makan "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.ControlLightLight
        Label3.Location = New Point(53, 51)
        Label3.Name = "Label3"
        Label3.Size = New Size(229, 38)
        Label3.TabIndex = 1
        Label3.Text = "APLIKASI KASIR"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = SystemColors.ActiveCaption
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label1)
        Panel2.Location = New Point(663, 41)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(320, 61)
        Panel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label2.Location = New Point(78, 17)
        Label2.Name = "Label2"
        Label2.Size = New Size(28, 32)
        Label2.TabIndex = 1
        Label2.Text = "0"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(22, 11)
        Label1.Name = "Label1"
        Label1.Size = New Size(60, 38)
        Label1.TabIndex = 0
        Label1.Text = "Rp."
        ' 
        ' cmbitem
        ' 
        cmbitem.Font = New Font("Segoe UI", 12F)
        cmbitem.FormattingEnabled = True
        cmbitem.Items.AddRange(New Object() {"Sate Ayam", "Ayam Goreng", "Nasi Goreng", "Ayam Geprek", "Bubur Medan"})
        cmbitem.Location = New Point(207, 228)
        cmbitem.Name = "cmbitem"
        cmbitem.Size = New Size(314, 40)
        cmbitem.TabIndex = 1
        ' 
        ' txtharga
        ' 
        txtharga.Font = New Font("Segoe UI", 12F)
        txtharga.Location = New Point(207, 291)
        txtharga.Name = "txtharga"
        txtharga.Size = New Size(268, 39)
        txtharga.TabIndex = 2
        ' 
        ' txtjumlah
        ' 
        txtjumlah.Font = New Font("Segoe UI", 12F)
        txtjumlah.Location = New Point(207, 345)
        txtjumlah.Name = "txtjumlah"
        txtjumlah.Size = New Size(268, 39)
        txtjumlah.TabIndex = 3
        ' 
        ' txtsubtotal
        ' 
        txtsubtotal.Font = New Font("Segoe UI", 12F)
        txtsubtotal.Location = New Point(207, 406)
        txtsubtotal.Name = "txtsubtotal"
        txtsubtotal.Size = New Size(268, 39)
        txtsubtotal.TabIndex = 4
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(207, 459)
        Button1.Name = "Button1"
        Button1.Size = New Size(147, 45)
        Button1.TabIndex = 5
        Button1.Text = "Sub Total"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' txtdiskon
        ' 
        txtdiskon.Font = New Font("Segoe UI", 12F)
        txtdiskon.Location = New Point(207, 529)
        txtdiskon.Name = "txtdiskon"
        txtdiskon.Size = New Size(260, 39)
        txtdiskon.TabIndex = 6
        ' 
        ' txttotal
        ' 
        txttotal.Font = New Font("Segoe UI", 12F)
        txttotal.Location = New Point(207, 588)
        txttotal.Name = "txttotal"
        txttotal.Size = New Size(260, 39)
        txttotal.TabIndex = 7
        ' 
        ' txtbayar
        ' 
        txtbayar.Font = New Font("Segoe UI", 12F)
        txtbayar.Location = New Point(768, 535)
        txtbayar.Name = "txtbayar"
        txtbayar.Size = New Size(255, 39)
        txtbayar.TabIndex = 8
        ' 
        ' txtkembali
        ' 
        txtkembali.Font = New Font("Segoe UI", 12F)
        txtkembali.Location = New Point(768, 591)
        txtkembali.Name = "txtkembali"
        txtkembali.Size = New Size(255, 39)
        txtkembali.TabIndex = 9
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(207, 643)
        Button2.Name = "Button2"
        Button2.Size = New Size(132, 41)
        Button2.TabIndex = 10
        Button2.Text = "Total"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(409, 724)
        Button4.Name = "Button4"
        Button4.Size = New Size(112, 43)
        Button4.TabIndex = 12
        Button4.Text = "Reset"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(552, 724)
        Button3.Name = "Button3"
        Button3.Size = New Size(112, 43)
        Button3.TabIndex = 13
        Button3.Text = "Close"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' cmbvoucher
        ' 
        cmbvoucher.Font = New Font("Segoe UI", 12F)
        cmbvoucher.FormattingEnabled = True
        cmbvoucher.Items.AddRange(New Object() {"Akhir Pekan", "Akhir Bulan", "Akhir Tahun", "Tidak Ada"})
        cmbvoucher.Location = New Point(767, 228)
        cmbvoucher.Name = "cmbvoucher"
        cmbvoucher.Size = New Size(255, 40)
        cmbvoucher.TabIndex = 14
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(78, 231)
        Label4.Name = "Label4"
        Label4.Size = New Size(94, 32)
        Label4.TabIndex = 15
        Label4.Text = "Menu :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label5.ForeColor = SystemColors.ActiveCaptionText
        Label5.Location = New Point(75, 297)
        Label5.Name = "Label5"
        Label5.Size = New Size(97, 32)
        Label5.TabIndex = 16
        Label5.Text = "Harga :"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label6.ForeColor = SystemColors.ActiveCaptionText
        Label6.Location = New Point(75, 351)
        Label6.Name = "Label6"
        Label6.Size = New Size(110, 32)
        Label6.TabIndex = 17
        Label6.Text = "Jumlah :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label7.ForeColor = SystemColors.ActiveCaptionText
        Label7.Location = New Point(75, 413)
        Label7.Name = "Label7"
        Label7.Size = New Size(134, 32)
        Label7.TabIndex = 18
        Label7.Text = "Sub Total :"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label8.ForeColor = SystemColors.ActiveCaptionText
        Label8.Location = New Point(75, 535)
        Label8.Name = "Label8"
        Label8.Size = New Size(107, 32)
        Label8.TabIndex = 19
        Label8.Text = "Diskon :"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label9.ForeColor = SystemColors.ActiveCaptionText
        Label9.Location = New Point(75, 594)
        Label9.Name = "Label9"
        Label9.Size = New Size(84, 32)
        Label9.TabIndex = 20
        Label9.Text = "Total :"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label10.Location = New Point(574, 231)
        Label10.Name = "Label10"
        Label10.Size = New Size(187, 32)
        Label10.TabIndex = 21
        Label10.Text = "Kode Voucher :"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label11.Location = New Point(574, 535)
        Label11.Name = "Label11"
        Label11.Size = New Size(159, 32)
        Label11.TabIndex = 22
        Label11.Text = "Uang Bayar :"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label12.Location = New Point(574, 594)
        Label12.Name = "Label12"
        Label12.Size = New Size(188, 32)
        Label12.TabIndex = 23
        Label12.Text = "Uang Kembali :"
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(696, 724)
        Button5.Name = "Button5"
        Button5.Size = New Size(112, 43)
        Button5.TabIndex = 24
        Button5.Text = "Simpan"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(23, 758)
        Button6.Name = "Button6"
        Button6.Size = New Size(259, 43)
        Button6.TabIndex = 25
        Button6.Text = "List Menu Yang Dipesan"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(1056, 831)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(cmbvoucher)
        Controls.Add(Button3)
        Controls.Add(Button4)
        Controls.Add(Button2)
        Controls.Add(txtkembali)
        Controls.Add(txtbayar)
        Controls.Add(txttotal)
        Controls.Add(txtdiskon)
        Controls.Add(Button1)
        Controls.Add(txtsubtotal)
        Controls.Add(txtjumlah)
        Controls.Add(txtharga)
        Controls.Add(Panel1)
        Controls.Add(cmbitem)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form1"
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbitem As ComboBox
    Friend WithEvents txtharga As TextBox
    Friend WithEvents txtjumlah As TextBox
    Friend WithEvents txtsubtotal As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents txtdiskon As TextBox
    Friend WithEvents txttotal As TextBox
    Friend WithEvents txtbayar As TextBox
    Friend WithEvents txtkembali As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents cmbvoucher As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button

End Class
